import { JobsApplied } from './jobs-applied';

describe('JobsApplied', () => {
  it('should create an instance', () => {
    expect(new JobsApplied()).toBeTruthy();
  });
});
