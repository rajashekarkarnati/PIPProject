export class Job {
    jobid : number
    jobtitle : string
    companytitle : string
    jobdescription : string
    createddate : Date
}
