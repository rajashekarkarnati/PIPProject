export class JobsApplied {
    id : number
    jobid : number
    studentid : number
    applieddate : Date
    resume : string
}
