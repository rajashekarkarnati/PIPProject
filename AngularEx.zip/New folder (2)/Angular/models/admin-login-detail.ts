export class AdminLoginDetail {
    id : number
    adminid : number
    adminpassword : string
}
