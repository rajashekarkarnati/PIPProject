export class StudentDetail {
    studentid : number
    studentname : string
    age : number
    gender : string
    dob : Date
    mobileno : string
    address : string
    password : string
    email : string
    photo : string
}
