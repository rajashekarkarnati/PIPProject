import { AdminLoginDetail } from './admin-login-detail';

describe('AdminLoginDetail', () => {
  it('should create an instance', () => {
    expect(new AdminLoginDetail()).toBeTruthy();
  });
});
