import { StudentDetail } from './student-detail';

describe('StudentDetail', () => {
  it('should create an instance', () => {
    expect(new StudentDetail()).toBeTruthy();
  });
});
