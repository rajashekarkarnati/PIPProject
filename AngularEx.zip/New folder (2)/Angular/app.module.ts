import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './components/login/login.component';
import { StudentDetailService } from './services/student-detail.service';
import { AdminLoginDetailService } from './services/admin-login-detail.service';
import { ManagestudentsComponent } from './components/managestudents/managestudents.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ManagestudentsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule, 
    ReactiveFormsModule, BrowserAnimationsModule, NgxPaginationModule
  ],
  providers: [StudentDetailService, AdminLoginDetailService],
  bootstrap: [AppComponent]
})
export class AppModule { }
