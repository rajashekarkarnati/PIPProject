import { Component, OnInit } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AdminLoginDetailService } from 'src/app/services/admin-login-detail.service';
import { Router, ActivatedRoute  } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import { StudentDetail } from 'src/app/models/student-detail';


@Component({
  selector: 'app-managestudents',
  templateUrl: './managestudents.component.html',
  styleUrls: ['./managestudents.component.css']
})
export class ManagestudentsComponent implements OnInit {
  students: StudentDetail[];
  config: any; 
  collection = [];

  constructor(private http : HttpClientModule,private route: ActivatedRoute, private service : AdminLoginDetailService, private router: Router ) { this.config = {
    currentPage: 1,
    itemsPerPage:5
  }
  this.route.queryParamMap.map(params => params.get('page'))
  .subscribe(page => this.config.currentPage= page);
 
}

pageChange(newPage: number) {
  this.router.navigate(['managestudents'], { queryParams: { page: newPage }});
  }

  ngOnInit() {
    this.service.GetAllStudents().subscribe(data => {
      this.students = data;
    });
  }

  deletestudent(student : StudentDetail){
    let result = confirm("Do you want to delete Product");
    if (result) {
      this.service.deletestudent(student.studentid).subscribe(data => {
        this.students = this.students.filter(u => u !== student);
      }, error => {console.log(error);})
    }
  }

}
