import { TestBed } from '@angular/core/testing';

import { AdminLoginDetailService } from './admin-login-detail.service';

describe('AdminLoginDetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminLoginDetailService = TestBed.get(AdminLoginDetailService);
    expect(service).toBeTruthy();
  });
});
