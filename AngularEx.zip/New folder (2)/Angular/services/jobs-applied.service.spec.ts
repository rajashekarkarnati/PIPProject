import { TestBed } from '@angular/core/testing';

import { JobsAppliedService } from './jobs-applied.service';

describe('JobsAppliedService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: JobsAppliedService = TestBed.get(JobsAppliedService);
    expect(service).toBeTruthy();
  });
});
