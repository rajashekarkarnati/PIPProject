import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StudentDetail } from '../models/student-detail';

@Injectable({
  providedIn: 'root'
})
export class AdminLoginDetailService {

  constructor(private http : HttpClient) { }


  public CheckAdminLogin(studentid : number, password : string){
    return this.http.get('https://localhost:44374/api/Login/AdminLogin?adminid=' + studentid + '&password=' + password);
  }

  public GetAllStudents(){
    return this.http.get<StudentDetail[]>('https://localhost:44374/api/Student/GetAllStudents');
  }

  public deletestudent(studentid : number){
    return this.http.get('https://localhost:44374/api/Student/DeleteStudent?studentid='+studentid);
  }
}
