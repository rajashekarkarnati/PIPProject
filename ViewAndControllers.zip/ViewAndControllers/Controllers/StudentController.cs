﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRepositorySystem.Models;
using StudentRepositorySystem.ViewModel;
using System.Threading;

namespace StudentRepositorySystem.Controllers
{
    public class StudentController : Controller
    {
        private masterEntities db = new masterEntities();
        // GET: Student
        public ActionResult DashBoard()
        {
            bool isAuth = isAuthorized();
            if (isAuth)
            {
                int studentid = Convert.ToInt32(Session["studentid"].ToString());
                var count = db.JobsApplieds.Where(a => a.studentid == studentid).Count();
                ViewBag.AppliedJobsCount = count;
                return View();
            }
            return View("UnAuthorized");
        }

        public ActionResult AddPhoto()
        {
            bool isAuth = isAuthorized();
            if (isAuth)
            {
                return View();
            }
            return View("UnAuthorized");
        }

        [HttpPost]
        public ActionResult AddPhoto(HttpPostedFileBase StudentImage)
        {
            int studentid = Convert.ToInt32(Session["studentid"].ToString());
            var filename = Path.GetFileName(StudentImage.FileName);
            filename = studentid.ToString() + ".jpg";
            var path = Path.Combine(Server.MapPath("~/Images/"), filename);
            StudentDetail student = db.StudentDetails.Where(a => a.studentid == studentid).FirstOrDefault();
            StudentImage.SaveAs(path);
            student.photo = filename;
            db.Entry(student).State = EntityState.Modified;
            db.SaveChanges();
            Session["imagepath"] = "~/Images/" + student.photo;
            Thread.Sleep(3000);
            //return Json(new { msg = "Image Added" }, JsonRequestBehavior.AllowGet);
            return RedirectToAction("AddPhoto");            
        }

        public ActionResult EditDetails()
        {
            bool isAuth = isAuthorized();
            if (isAuth)
            { 
                int studentid = Convert.ToInt32(Session["studentid"].ToString());
                StudentDetail student = db.StudentDetails.Where(a => a.studentid == studentid).FirstOrDefault();
                ViewBag.dob = student.dob;
                return View(student);
            }
            return View("UnAuthorized");
        }

        [HttpPost]
        public ActionResult EditDetails(StudentDetail student)
        {
            StudentDetail student1 = db.StudentDetails.Find(student.studentid);
            student1.studentname = student.studentname;
            student1.age = student.age;
            student1.dob = student.dob;
            student1.gender = student.gender;
            student1.mobileno = student.mobileno;
            student1.address = student.address;
            student1.password = student.password;
            student1.email = student.email;
            db.Entry(student1).State = EntityState.Modified;
            db.SaveChanges();
            return Json(new { msg="Successfully Changed"}, JsonRequestBehavior.AllowGet);
            //return RedirectToAction("DashBoard");
        }

        public ActionResult AppliedJobs()
        {
            bool isAuth = isAuthorized();
            if (isAuth)
            {
                int studentid = Convert.ToInt32(Session["studentid"].ToString());
                var jobsApplied = db.JobsApplieds.Where(a => a.studentid == studentid).ToList();
                return View(jobsApplied);
            }
            return View("UnAuthorized");
        }

        public ActionResult ChangePassword()
        {
            int studentid = Convert.ToInt32(Session["studentid"].ToString());
            var student = db.StudentDetails.Find(studentid);
            ChangePassword cp = new ChangePassword()
            {
                studentid = studentid,
                oldpassword = student.password,
            };
            return View(cp);
        }

        [HttpPost]
        public ActionResult ChangePassword(int? studentid,string newpassword)
        {
            var student = db.StudentDetails.Find(studentid);
            if(student != null)
            {
                student.password = newpassword;
                db.Entry(student).State = EntityState.Modified;
                db.SaveChanges();
                return Json(new { status="suceess"}, JsonRequestBehavior.AllowGet);
            }
            return View();
        }

        public bool isAuthorized()
        {
            bool auth = false;
            if(Session["usertype"].ToString() == "student")
            {
                auth = true;
            }
            return auth;
        }
    }
}